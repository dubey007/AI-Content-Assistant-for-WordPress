<?php

class WP_AI_Admin_Settings {

    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'register_settings']);
    }

    public function add_menu() {
        add_options_page(
            'AI Settings',
            'AI Assistant',
            'manage_options',
            'wp-ai-settings',
            [$this, 'settings_page']
        );
    }

    public function register_settings() {
        register_setting('wp_ai_settings_group', 'wp_ai_api_key');
    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>AI Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('wp_ai_settings_group'); ?>
                <input type="text" name="wp_ai_api_key" value="<?php echo esc_attr(get_option('wp_ai_api_key')); ?>" />
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}
