<?php
/**
 * Plugin Name: WP AI Content Assistant
 * Description: AI-powered content generator inside WordPress editor.
 * Version: 1.0
 * Author: Avinash Kumar Dubey
 */

if (!defined('ABSPATH')) {
    exit;
}

define('WP_AI_PLUGIN_PATH', plugin_dir_path(__FILE__));

require_once WP_AI_PLUGIN_PATH . 'includes/class-admin-settings.php';
require_once WP_AI_PLUGIN_PATH . 'includes/class-ai-service.php';
require_once WP_AI_PLUGIN_PATH . 'includes/class-rest-controller.php';

add_action('plugins_loaded', function () {
    new WP_AI_Admin_Settings();
    new WP_AI_REST_Controller();
});
